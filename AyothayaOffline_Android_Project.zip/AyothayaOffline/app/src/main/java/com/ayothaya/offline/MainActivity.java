package com.ayothaya.offline;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings; import android.view.View;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512); WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); w.setBackgroundColor(0xff162a25); w.loadUrl("file:///android_asset/index.html"); setContentView(w); }
 @Override public void onBackPressed(){ super.onBackPressed(); }
}
